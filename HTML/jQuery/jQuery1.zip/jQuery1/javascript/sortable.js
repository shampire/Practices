$(function () {

//DefaultOption = { imposedOnID: "#sortable", defaultLayout: "enlarged", RightLargeFrameLi: "#li3", };
       //$('#sortable').sortablePlugin(opts = { imposedOnID: "#sortable", defaultLayout: "normal", RightLargeFrameLi: "#li3", }); 
       $('#sortable').sortablePlugin();
});

